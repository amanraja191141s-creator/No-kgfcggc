# SA Calculator — v98.63.9.10

A mobile-first calculator application with standard and scientific calculation, history, favorites, themes, localization, tools, unit conversion, and currency conversion. Android packaging uses Capacitor.

## Release identity

- Package version: `1.98.66-v98.63.9.18`
- Android versionCode: `1098066`
- Patch label: `v98.63.9.10`

The patch label identifies this source update; the package identity remains stable for this patch line.

## Requirements

- Node.js 22+
- npm
- Java 21 (Temurin recommended)
- Android SDK and Android build-tools for APK builds

## Install, test and build the web bundle

```sh
npm install
npm test
npm run build:web
```

`npm test` runs the complete Node regression suite. `npm run build:web` prepares the Capacitor `www/` directory from the canonical project source and verifies the required packaged assets.

## Android project and APK

Generate the native Android project once:

```sh
npx cap add android
```

Then sync and build:

```sh
npm run android:sync
npm run android:apk
```

The debug APK is produced at:

```text
android/app/build/outputs/apk/debug/app-debug.apk
```

The GitHub Actions workflow at `.github/workflows/main.yml` validates the exact package version, checks source files and JavaScript syntax, builds the web bundle, runs regression tests, syncs Capacitor, applies native branding, and builds/verifies a debug APK.

## App areas

- **Calculator:** standard arithmetic, live expression and result preview.
- **Scientific calculator:** trigonometric, logarithmic, power, root, angle and memory functions.
- **Tools:** dedicated calculators and utilities.
- **Converters:** currency and unit conversion with searchable selectors.
- **History:** saved calculations with restore, copy, share and clear actions.
- **Favorites:** quick access to favorite tools.
- **Settings:** appearance, accent palette, localization and preferences.

## Current verification boundary

Automated source tests and the Android web-bundle build can be run in the project environment. A passing automated suite does not prove physical-device rendering, APK installation, live exchange-rate provider availability, frame rate, battery/memory behavior, or compatibility with every Android WebView and OEM keyboard. Those checks require a real device/emulator and network access.

## 3. Calculator home — Basic

Standard arithmetic keypad and live expression/result display.

## 4. Scientific Calculator

Trigonometric, logarithmic, power, root, angle and memory functions.

## 5. Tools catalogue

Dedicated calculators and utilities.

## 7. History

Saved calculations with restore, copy, share and clear actions.

## 8. Favorites

Quick access to favorite tools.

## 9. Settings

Appearance, accent palette, localization and app preferences.

## 10. Dialogs, pickers, menus and feedback

Contextual dialogs and dedicated selection controls.

## 13. Regression and device test matrix

Automated source tests are available; physical device testing is a separate release check.

The keypad is numeric only; never render all currency country names or unit names among digit keys. Tool inputs use dedicated selectors where appropriate. Base-aware keypad. Date entry uses the native date picker where supported.


## v98.63.9.16 — Converter picker and flag repair

- Currency and unit option catalogs are visible immediately when their picker opens.
- Search is optional and filters the full catalog from the first typed character.
- Currency options show a flag glyph, localized currency name, ISO code and region.
- Currency selector cards explicitly keep their flag spans visible.
- Unit option rows use a full-width label grid; they no longer reserve an empty flag column.
- Picker options use a consistent dark panel, clear selected state, scroll behavior and touch targets.
- Search results and selection continue to use the existing native select values and conversion paths.


## v98.63.9.18 — right-edge scientific keypad drawer
- Portrait calculator layout now allocates 36% to the display and 64% to the keypad.
- Key cells fill 95–97% width and 96% height; the 4×5 keypad and double-width zero are preserved.
- Editable expression text fits from 30px down to 18px; live preview from 56px down to 22px; committed result from 64px down to 22px.
- Text fitting is measured against the available row width using binary search. Display-only scientific compaction is used only when needed and does not change the canonical value.
- Android web assets, PWA cache namespace and build identity refreshed.


### v98.63.9.18 — scientific edge-swipe integration
- Moved the existing scientific calculator workspace into a right-side drawer nested inside the standard calculator.
- Open by swiping left from the right screen edge; close by swiping right from within the drawer.
- Added an explicit close control and Escape-key support; drawer uses ARIA visibility and inert state.
- Removed the separate Scientific Calculator card from the Tools catalog.
- Preserved scientific expression parsing, DEG/RAD, SHIFT functions, memory, ANS and scientific history.
- Updated the Android web bundle and service-worker cache identity.

- `npm test` runs the current release regression suite. `npm run test:legacy` runs the historical full test corpus; some archived assertions intentionally describe superseded standalone scientific-screen behaviour and older exact release IDs.
