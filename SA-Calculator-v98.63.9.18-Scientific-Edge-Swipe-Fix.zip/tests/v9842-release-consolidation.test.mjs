import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');
test('production loads exactly one canonical stylesheet; historical layers are removed', () => {
 const html=read('index.html');
 const links=[...html.matchAll(/<link\s+rel="stylesheet"[^>]*href="([^"]+)"/g)].map(m=>m[1]);
 assert.deepEqual(links,['assets/css/app.css']);
 assert.ok(fs.existsSync('assets/css/app.css'));
 assert.ok(fs.existsSync('assets/css/app.css'));
 assert.doesNotMatch(html,/sa-css-source-layers|rebuild-v98\./);
});
test('Android web builder copies the canonical stylesheet and never concatenates legacy CSS layers',()=>{
 const builder=read('scripts/prepare-android-web.mjs'); const sw=read('service-worker.js');
 assert.match(builder,/assets\/css\/app\.css/);
 assert.doesNotMatch(builder,/rebuild-v98\.|app-base\.css/);
 assert.match(sw,/\.\/assets\/css\/app\.css/);
 assert.doesNotMatch(sw,/rebuild-v98\./);
});
test('historical CSS source layers are removed from production and Android runtime',()=>{
 const files=fs.readdirSync('www/assets/css');
 assert.deepEqual(files,['app.css']);
 assert.equal(read('assets/css/app.css'),read('www/assets/css/app.css'));
});
